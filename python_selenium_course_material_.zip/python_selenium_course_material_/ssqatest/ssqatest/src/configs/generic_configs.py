


class GenericConfigs:

    FREE_COUPON = 'SSQA100'
    DATABASE_SCHEMA = 'localdemostore'
    DATABASE_TABLE_PREFIX = 'wp_'