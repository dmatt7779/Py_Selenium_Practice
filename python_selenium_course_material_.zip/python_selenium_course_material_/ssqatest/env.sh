

export BROWSER=chrome

export RESULTS_DIR=./results