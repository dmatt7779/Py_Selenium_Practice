"""
// relative xpath
/ absolute xpath

//tag[@attribute='value']
//*[@attribute='value']
"""
# cart
#  //*[@id="site-header-cart"]
# //ul[@id="site-header-cart"]'
# /html/body/div/header/div[2]/div/ul
# '//ul[contains(@id, "site")]'
# '//a[text()="Lost your password?"]'
# '//a[contains(text(), "password?")]'