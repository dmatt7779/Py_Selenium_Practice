# Variable examples

name = 'John'
title = "Sr. Software Eng in Test"
field = "Software Engineering"
age = 30

print("====================")

print("Current user's name: " + name)
print("current user's title: " + title)
print("Current user's age: " + str(age))

print("{} creates the best courses in the field of {}".format(name, field))

country = 'USA'
_country = 'USA'
country = 'USA'
countr2 = "Indea"
cou3ntry3 = "France"